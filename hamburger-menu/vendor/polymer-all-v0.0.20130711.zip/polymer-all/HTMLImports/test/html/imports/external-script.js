window.externalScriptParsed = new Date().getTime();
